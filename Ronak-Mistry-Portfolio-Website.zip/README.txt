RONAK MISTRY PORTFOLIO
======================
1. Open index.html in a browser to preview the site.
2. Upload index.html to GitHub Pages, Netlify, or another static host to publish it.
3. Replace the LinkedIn placeholder in index.html with your actual LinkedIn URL.
